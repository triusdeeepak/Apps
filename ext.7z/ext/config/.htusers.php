<?php 
	// ensure this file is being included by a parent file
	if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
	$GLOBALS["users"]=array(
	array('admin','$2a$08$GCReYO7CqBLBEdpV8jNinOWPszscR1YQaw0OYQy9d977rZxjpHWV6','D:/wamp/www/','http://localhost','1','','7',1),
); 
?>